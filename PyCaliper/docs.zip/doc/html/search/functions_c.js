var searchData=
[
  ['unregisteruom_0',['unregisterUOM',['../classuom_1_1cache__manager_1_1_cache_manager.html#aa37c2c9550accb8621bd31b87b3d4bd3',1,'uom::cache_manager::CacheManager']]]
];
