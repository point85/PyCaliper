var searchData=
[
  ['unregisteruom',['unregisterUOM',['../classuom_1_1cache__manager_1_1_cache_manager.html#ae6b7086891fee3769e728569f9f862b4',1,'uom::cache_manager::CacheManager']]]
];
