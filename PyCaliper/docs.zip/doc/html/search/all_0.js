var searchData=
[
  ['_5f_5finit_5f_5f',['__init__',['../classuom_1_1prefix_1_1_prefix.html#ac2de7561e3f48d8ae8bc8425eb426797',1,'uom.prefix.Prefix.__init__()'],['../classuom_1_1quantity_1_1_quantity.html#a4501c30588fc85eab74256da07fc7f14',1,'uom.quantity.Quantity.__init__()']]]
];
