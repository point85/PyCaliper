var searchData=
[
  ['_5f_5finit_5f_5f_0',['__init__',['../classuom_1_1prefix_1_1_prefix.html#a0b5b0826a6a4d18ded8251c8fb791fe9',1,'uom.prefix.Prefix.__init__()'],['../classuom_1_1quantity_1_1_quantity.html#a3607ea924842331f9847e7c7ef679346',1,'uom.quantity.Quantity.__init__()']]]
];
