var searchData=
[
  ['registeruom',['registerUOM',['../classuom_1_1cache__manager_1_1_cache_manager.html#a5ad983cf1a1571b905f12cedf1c35486',1,'uom::cache_manager::CacheManager']]]
];
