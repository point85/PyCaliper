var searchData=
[
  ['divide_0',['divide',['../classuom_1_1quantity_1_1_quantity.html#aec928c983d33f4be7fb41feafaa33f2b',1,'uom.quantity.Quantity.divide()'],['../classuom_1_1unit__of__measure_1_1_unit_of_measure.html#a8b9a07def0c1370748a1f2e6e9333332',1,'uom.unit_of_measure.UnitOfMeasure.divide()']]],
  ['dividebyamount_1',['divideByAmount',['../classuom_1_1quantity_1_1_quantity.html#ad4098b62405042fb01e35ab4cf76a903',1,'uom::quantity::Quantity']]]
];
