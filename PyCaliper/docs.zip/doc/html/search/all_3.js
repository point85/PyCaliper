var searchData=
[
  ['divide',['divide',['../classuom_1_1quantity_1_1_quantity.html#a84ed970f2b44bc18ecb0d0fc7a1b25fe',1,'uom.quantity.Quantity.divide()'],['../classuom_1_1unit__of__measure_1_1_unit_of_measure.html#a9ebf445b87d16c7acfb51cc3198e141d',1,'uom.unit_of_measure.UnitOfMeasure.divide()']]],
  ['dividebyamount',['divideByAmount',['../classuom_1_1quantity_1_1_quantity.html#a416da5ffb93eac9df38cecea6d149c14',1,'uom::quantity::Quantity']]]
];
