var searchData=
[
  ['setconversion_0',['setConversion',['../classuom_1_1unit__of__measure_1_1_unit_of_measure.html#aab1d91e45405206e86bb5a859852b7f0',1,'uom::unit_of_measure::UnitOfMeasure']]],
  ['setpowerunit_1',['setPowerUnit',['../classuom_1_1unit__of__measure_1_1_unit_of_measure.html#ad03dbad85aa3980adb78670faa50079a',1,'uom::unit_of_measure::UnitOfMeasure']]],
  ['setproductunits_2',['setProductUnits',['../classuom_1_1unit__of__measure_1_1_unit_of_measure.html#a76a678319178ac278c982f55049db211',1,'uom::unit_of_measure::UnitOfMeasure']]],
  ['setquotientunits_3',['setQuotientUnits',['../classuom_1_1unit__of__measure_1_1_unit_of_measure.html#a1c1d434a26c43f4609523b0d778b026e',1,'uom::unit_of_measure::UnitOfMeasure']]],
  ['subtract_4',['subtract',['../classuom_1_1quantity_1_1_quantity.html#ae825298b8e98de5f494f23117be4eedd',1,'uom::quantity::Quantity']]]
];
