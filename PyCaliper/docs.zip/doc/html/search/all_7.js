var searchData=
[
  ['langstr',['langStr',['../classuom_1_1localizer_1_1_localizer.html#a7d7903c5dd30101f4ac072e977a48f25',1,'uom::localizer::Localizer']]],
  ['localizer',['Localizer',['../classuom_1_1localizer_1_1_localizer.html',1,'uom::localizer']]]
];
