var searchData=
[
  ['langstr_0',['langStr',['../classuom_1_1localizer_1_1_localizer.html#a4d9c6de0511c66c45fe41d27964358a9',1,'uom::localizer::Localizer']]],
  ['localizer_1',['Localizer',['../classuom_1_1localizer_1_1_localizer.html',1,'uom::localizer']]]
];
