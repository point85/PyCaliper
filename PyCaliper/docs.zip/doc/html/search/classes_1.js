var searchData=
[
  ['localizer_0',['Localizer',['../classuom_1_1localizer_1_1_localizer.html',1,'uom::localizer']]]
];
