var searchData=
[
  ['localizer',['Localizer',['../classuom_1_1localizer_1_1_localizer.html',1,'uom::localizer']]]
];
