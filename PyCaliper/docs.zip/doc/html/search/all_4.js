var searchData=
[
  ['fromfactor_0',['fromFactor',['../classuom_1_1prefix_1_1_prefix.html#a9d7e5e1ddf0b31ad1f7dcdff226ca210',1,'uom::prefix::Prefix']]],
  ['fromname_1',['fromName',['../classuom_1_1prefix_1_1_prefix.html#aa282092382eaa6f706f82550181fd327',1,'uom::prefix::Prefix']]]
];
