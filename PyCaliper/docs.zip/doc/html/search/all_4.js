var searchData=
[
  ['fromfactor',['fromFactor',['../classuom_1_1prefix_1_1_prefix.html#a33433eb2343119a7f18520ec812ec02c',1,'uom::prefix::Prefix']]],
  ['fromname',['fromName',['../classuom_1_1prefix_1_1_prefix.html#a04102ae9eea4b4dbeed32fe4c10cfcc9',1,'uom::prefix::Prefix']]]
];
