var searchData=
[
  ['invert_0',['invert',['../classuom_1_1quantity_1_1_quantity.html#a0cd1c6e2783b02701f36f959511262db',1,'uom.quantity.Quantity.invert()'],['../classuom_1_1unit__of__measure_1_1_unit_of_measure.html#aa28c70c1afe80e78dfdf842c74e66fdf',1,'uom.unit_of_measure.UnitOfMeasure.invert(self)']]],
  ['isterminal_1',['isTerminal',['../classuom_1_1unit__of__measure_1_1_unit_of_measure.html#a694c65dcda8c6f9659d1c4ccad26cb04',1,'uom::unit_of_measure::UnitOfMeasure']]],
  ['isvalidexponent_2',['isValidExponent',['../classuom_1_1unit__of__measure_1_1_unit_of_measure.html#ad546ae005a03a1c40efd394b19f2dc7e',1,'uom::unit_of_measure::UnitOfMeasure']]]
];
