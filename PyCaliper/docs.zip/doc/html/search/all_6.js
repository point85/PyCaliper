var searchData=
[
  ['invert',['invert',['../classuom_1_1quantity_1_1_quantity.html#aa1b3ce146f604cde18b683a5674a11c9',1,'uom.quantity.Quantity.invert()'],['../classuom_1_1unit__of__measure_1_1_unit_of_measure.html#a8c5d2d224b7e691ff5d765163f5cca25',1,'uom.unit_of_measure.UnitOfMeasure.invert()']]],
  ['isterminal',['isTerminal',['../classuom_1_1unit__of__measure_1_1_unit_of_measure.html#aa9e6f9f49b93c6443da2e07094e20e48',1,'uom::unit_of_measure::UnitOfMeasure']]],
  ['isvalidexponent',['isValidExponent',['../classuom_1_1unit__of__measure_1_1_unit_of_measure.html#a49b9643890c1ed1ab4d1a718dc6384c1',1,'uom::unit_of_measure::UnitOfMeasure']]]
];
